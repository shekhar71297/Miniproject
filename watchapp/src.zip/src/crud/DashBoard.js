import React, { Component } from 'react'
import { Table } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import axios from 'axios'
import img1 from '../Assets/Images/Emi.webp'
// import { createStructuredSelector } from 'reselect'
import { connect } from 'react-redux'

// import { getAllProducts } from '../selectors/ProductSelectors'

import * as productAction from '../action/ProductAction'


export class DashBoard extends Component {
    constructor(props) {
        super(props)

        this.state = {
            products: []

        }
    }
    componentDidUpdate(prevProps) {
        if (prevProps.allProducts !== this.props.allProducts) {
            // Fetch data when allProducts prop changes
            this.props.initProductRequest();
        }
    }
    componentDidMount() {
        // this.fetchData()
        this.props.initProductRequest()
    }

    // fetchData = () => { 
    // axios.get("http://localhost:8888/Products").then((res)=>{
    //     this.setState({products:res.data})
    //     this.props.initProductRequest()
    //     console.log(res.data);
    // })
 


    // }

    deleteItem = (id, pName) => {
        if (window.confirm(`Are you sure? you want to remove product:${pName} `)) {
            let url = `${"http://localhost:8888/Products"}/${id}`
            axios.delete(url).then(() => {
                window.alert("Product Deleted successfully")
                // this.fetchData()
                this.props.initProductRequest()
            })
        }


    }



    render() {

        console.log(this.props.allProducts)

        // const { products } = this.state

        let total = 0
        for (let i of this.props.allProducts) {
            total += i.pPrice
        }
        console.log("total:", total);

        return (

            <div>


                {/* <div className='float:end'>
                <Link to="/add" className='btn btn-primary mb-2'>
                <i class="fa fa-plus" aria-hidden="true"></i>Add
                  </Link>
                </div>
               */}
                <img src={img1} alt='emi' height={300} width={'100%'} />
                <Table striped bordered hover variant="dark">

                    <thead>
                        <tr>
                            <th>PRODUCT-ID</th>
                            <th>PRODUCT-NAME</th>
                            <th>PRODUCT-TYPE</th>
                            <th>PRODUCT-PRICE</th>
                            <th>ACTION</th>
                        </tr>

                    </thead>
                    <tbody>
                        {
                            this.props.allProducts.map((PRO, index) => {
                                return <tr key={index}>
                                    <td>{PRO.pId}</td>
                                    <td>{PRO.pName}</td>
                                    <td>{PRO.pType}</td>
                                    <td>{PRO.pPrice}</td>
                                    <td>
                                        {/* <button type='button'className='btn btn-outline-success btn-sm' ><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>| */}
                                        <button type='button' className='btn btn-outline-danger btn-sm' onClick={() => this.deleteItem(PRO.id)}><i class="fa fa-trash-o" aria-hidden="true"></i></button>

                                    </td>
                                </tr>
                            })
                        }
                    </tbody>
                </Table>
                <Table style={{ backgroundColor: "black", height: "80px", color: "White", fontSize: 20 }}>

                    <tr>
                        <td className='float-end'><strong className='text-white'>Total Amount:</strong>{total}₹</td>

                    </tr>
                    <Link to='/order' className='btn btn-warning'>Place Order</Link>
                </Table>

            </div>

        )

    }

}
// const mapStateToProps = createStructuredSelector({
//     allProducts: getAllProducts

// })
const mapStateToProps = (state) => ({
    allProducts: state.productStore.allProducts

})
const mapDispatchToProps = (dispatch) => ({
    initProductRequest: () => dispatch(productAction.getAllproducts())
})
export default connect(mapStateToProps, mapDispatchToProps)(DashBoard)
