// import React, { Component } from 'react'
import img1 from '../Assets/Images/watch1.jpg'
import img2 from '../Assets/Images/watch2.jpg'
import img3 from '../Assets/Images/watch3.jpg'
import img4 from '../Assets/Images/watch4.jpg'
import img5 from '../Assets/Images/watch5.jpg'
import img6 from '../Assets/Images/watch6.jpg'
import img7 from '../Assets/Images/watch7.jpg'
import img8 from '../Assets/Images/watch8.jpg'
import img9 from '../Assets/Images/watch9.jpg'
import img10 from '../Assets/Images/watch10.jpg'
import img11 from '../Assets/Images/watch11.jpg'
import img12 from '../Assets/Images/watch12.jpg'
import img13 from '../Assets/Images/watch13.jpg'
import img14 from '../Assets/Images/watch14.jpg'
import product1 from '../Assets/Images/prduct1.png'
import product2 from '../Assets/Images/product2.png'
import product3 from '../Assets/Images/product3.png'
import product4 from '../Assets/Images/product4.png'
import product5 from '../Assets/Images/product5.png'
import product6 from '../Assets/Images/product6.png'
import product7 from '../Assets/Images/product7.png'
import product8 from '../Assets/Images/product8.png'
import product9 from '../Assets/Images/product9.png'
import product10 from '../Assets/Images/product10.png'
import digi1 from '../Assets/Images/timaxdigi1.webp'
import digi2 from '../Assets/Images/t2digi.webp'
import digi3 from '../Assets/Images/smart1f.webp'
import digi4 from '../Assets/Images/smart2f.webp'
import digi5 from '../Assets/Images/smart3.webp'
import digi6 from '../Assets/Images/smart4.webp'
import men1 from '../Assets/Images/men1.webp'
import men2 from '../Assets/Images/men2.webp'
import men3 from '../Assets/Images/men3.webp'
import men4 from '../Assets/Images/men4.webp'
import men5 from '../Assets/Images/t3.webp'
import men6 from '../Assets/Images/t4.webp'
import women1 from '../Assets/Images/women1.webp'
import women2 from '../Assets/Images/women2.webp'
import women3 from '../Assets/Images/women3.webp'
import women4 from '../Assets/Images/women4.webp'
import women5 from '../Assets/Images/women5.webp'
import women6 from '../Assets/Images/women6.webp'
import home1 from '../Assets/Images/hompage.jpg'
import about1 from '../Assets/Images/about1.jpg'
import about2 from '../Assets/Images/about2.png'
import about3 from '../Assets/Images/about3.jpg'
import about4 from '../Assets/Images/about4.jpg'
import about5 from '../Assets/Images/about5.jpeg'
import cont1 from '../Assets/Images/aboutT1.jpg'
import about6 from '../Assets/Images/About6.jpg'
import service from '../Assets/Images/SL-080420-33360-35.jpg'
import feed from '../Assets/Images/feedimg-removebg-preview.png'



const constantData={
 img1,product1,digi5,home1,
 img2,product2,digi6,about1,
 img3,product3,men1,about2,
 img4,product4,men2,about3,
 img5,product5,men3,about4,
 img6,product6,men4,about5,
 img7,product7,men5,cont1,
 img8,product8,men6,about6,
 img9,product9,women1,service,
 img10,product10,women2,feed,
 img11,digi1,women3,
 img12,digi2,women4,
 img13,digi3,women5,
 img14,digi4,women6
}

export default constantData
