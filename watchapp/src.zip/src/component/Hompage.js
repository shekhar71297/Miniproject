import React, { Component } from 'react'
import constantData from '../shared/Constant'

export class Hompage extends Component {
    render() {
        return (
            <div>
                <img src={constantData.home1} height={300} width={300}/>
                
            </div>

        )
    }
}

export default Hompage
